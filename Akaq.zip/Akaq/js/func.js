
    var a = {
        price:1.99,
        total:1.99,
        quantity:1,

    }
    var b = {
        price:2.99,
        total:2.99,
        quantity:2,

    }
    var c = {
        price:3.99,
        total:3.99,
        quantity:1,

    }

    

     function increment(d){
       render (d, 'add');

     }
     function decrement(d){
         render (d, 'sub');

     }

     function remove(d){
         render(d, 'remove');

     }
     function sendData(){
         alert('Hurray! your order is successfully placed')
         console.log(JSON.stringify({a,b,c}))
     }
    

    function render(d, type){
        var obj = d === 'obj1' ? a : (d === 'obj2' ? b : c);
       if(type == 'add') {
         if(obj.quantity < 10) {
           obj.quantity = obj.quantity + 1;
           obj.total = obj.quantity * obj.price;
         }
      } 
        else if(type == 'sub') {
          if(obj.quantity > 0) {
           obj.quantity = obj.quantity - 1;
           obj.total = obj.quantity * obj.price;
         }  
      }  else {
           obj.quantity = 0;
           obj.total = 0;
           document.getElementById(d+'Row').style.display='none';
           document.getElementById(d+'Button').style.display='none';
         }
      if (type !==  'remove') {
        document.getElementById(d+'List').innerText = '$'+obj.total.toFixed(2);
        document.getElementById(d+'Text').value = obj.quantity;
      }
        var subcost = a.total+b.total+c.total;
        var vat = (20*subcost)/100;
        document.getElementById('subCost').innerText = '$'+subcost.toFixed(2);
        document.getElementById('vat').innerText = '$'+vat.toFixed(2);
        document.getElementById('cost').innerText = '$'+(vat+subcost).toFixed(2);

       if(subcost == 0){
           var d = document.getElementById('buyButton');
           d.disabled = true;
           d.style.backgroundColor = 'gray';
       } else {
           var d = document.getElementById('buyButton');
           d.disabled = false;
           d.style.backgroundColor = 'rgb(38, 26, 138)';
       }
    }